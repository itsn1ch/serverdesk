# Resume ServerDesk on another machine

This folder transfers the paused implementation and its context. It does not contain a completed or verified application release.

The saved Git commit is `5da96b38ac502fc9daa9730b16c6c2c3ffebfde3`. The branch is `feat/serverdesk-ticket-implementation`.

## Restore the project

Use Linux with Git, Python 3, GNU tar, and sha256sum. The destination must not exist. These commands do not require network access.

Open a terminal in this artifact folder, then run the following commands. Choose a different `DEST` if that directory already exists.

```sh
set -eu
PACKAGE="$PWD"
DEST="$HOME/Projects/VPS-Management"
sha256sum -c SHA256SUMS
test ! -e "$DEST"
mkdir -p "$(dirname "$DEST")"
git init "$DEST"
git -C "$DEST" fetch "$PACKAGE/session-code.bundle" HEAD
git -C "$DEST" switch -c feat/serverdesk-ticket-implementation FETCH_HEAD
tar --no-same-owner -xzf "$PACKAGE/session-source.tar.gz" -C "$DEST"
git -C "$DEST" rev-parse HEAD
```

The last command must print the full saved commit above. The archive overlays the saved working tree, including the preexisting user edits and untracked project setup files. A dirty working tree after restoration is expected. Do not reset it.

Do not apply `remaining-user-changes.patch` after extracting the archive. The same changes are already included. The patch is a separate backup for reference.

## Continue with an assistant

Open the restored project as the assistant's working directory. Give the next assistant this instruction.

```text
Read .verification/serverdesk-program/SESSION-HANDOFF.md and the project instructions.
This is the saved ServerDesk session at WIP commit 5da96b3.
The implementation is unfinished. Preserve the existing user edits.
First fix the recorded Clippy findings and verify the latest askpass socket cleanup.
Then run the recorded integration and native UI journeys before accepting any ticket.
Continue the remaining numbered tickets only when I explicitly ask you to resume.
Treat old absolute paths as historical paths, not as paths on this machine.
```

Git remotes, hooks, stash refs, and the old `.git/xstack-worker` job database are not transferred. The original stash mentioned in the historical handoff is not a stash in the restored repository. Its already-integrated whitespace edits are present in the source snapshot.
The filesystem note and evidence replace the previous assistant's in-memory state. The artifact does not transfer the live chat, API credentials, editor sessions, running processes, or the previous host's agent-transcript service.

## Prepare the new environment

Restore the project before installing dependencies or running setup. The snapshot already contains project-local skills, domain documents, specifications, and numbered tickets.

- Install a Rust toolchain that supports edition 2024, including rustfmt and Clippy. The project does not pin an MSRV. Read `host-tool-versions.txt` for the previous host's actual versions. The unfinished code may need compatibility corrections on an older toolchain.
- Install Bun if you need the pinned Prettier formatter. Run `bun install --frozen-lockfile` from the restored project.
- Install the native development libraries required by Cargo. The configured features require GTK 4.14, libadwaita 1.5, and VTE 0.70 or newer. Consult the target distribution's packages and `pkg-config` rather than assuming the previous host's library paths.
- Native verification also uses system OpenSSH, an owned disposable sshd fixture, Xvfb, a private D-Bus session, Python GI with AT-SPI, and X11 XTest support.
- Rust dependencies and development packages are not vendored here. Installing them may require network access. Restoring the source itself does not.

`xstack-source.tar.gz` contains the previous installation's workflow-tool source and licenses. It excludes Git metadata, compiled targets, and node_modules. It does not include global model settings or provider credentials.

To use this source, choose a new, empty tool directory. Do not overwrite an existing installation.

```sh
set -eu
PACKAGE="$PWD"
XSTACK="$HOME/.local/share/xstack"
test ! -e "$XSTACK"
mkdir -p "$XSTACK"
tar --no-same-owner -xzf "$PACKAGE/xstack-source.tar.gz" -C "$XSTACK"
cargo install --locked --path "$XSTACK/worker"
cargo install --locked --path "$XSTACK/subtasks"
export PATH="$HOME/.cargo/bin:$PATH"
```

The installation commands above are instructions for the new machine. Packaging did not build or install these tools again.

Run the restored project's `/setup-xstack` flow before other workflow skills. Retain the saved project tracker and approved product policies. Reconfigure machine-local paths and available model roles for the new assistant environment. Do not copy or invent credentials. A `SUBTASK HOT` or `XSTACK READY` observation from the old session is not proof that the new machine is configured.

## Handle old verification paths

`SESSION-HANDOFF.md`, some capture helpers, and configuration pointers record absolute paths from the previous workstation. Do not recreate `/home/nichola` or overwrite another account's files.

The source archive includes these old external dependencies under the restored project.

- `.verification/capture-inventory-desktop.py` is the saved native keyboard and screenshot helper. Existing capture scripts still reference its old `/tmp/serverdesk-e2-inventory/` location. Update their local path references to the restored helper before driving them.
- `.verification/openssh-server/` is the extracted OpenSSH package used by the old fixture. Its binaries are architecture and distribution dependent. Prefer the new machine's compatible system sshd and set `SERVERDESK_TEST_SSHD` to its absolute path. Do not treat the copied binary as portable or install it over system files.
- `.verification/serverdesk-program/` contains selected verification scripts, logs, screenshots, and the checkpoint ledger. It does not contain every artifact produced during the previous program.

Old Incus instances, their network addresses, permission grants, live masters, and test databases are not transferred. Ubuntu 24.04 and systemd 255 integration acceptance remains externally blocked until the new machine has an authorized disposable fixture. Never run disk-full tests on the host filesystem.

## Know the unfinished state

The WIP includes the actual local audit and recovery path, trust changes, direct trust/configuration preparation, and newly integrated OpenSSH, askpass, and VTE code. The latest combined release checks have not passed.

The known lint failures and unverified cleanup change are listed in `SESSION-HANDOFF.md`. No ticket becomes accepted by copying this folder. The existing build output was intentionally excluded. Build the restored source before launching it.

## Files in this folder

| File                           | Purpose                                                                               |
| ------------------------------ | ------------------------------------------------------------------------------------- |
| `session-code.bundle`          | Git history through the saved WIP commit.                                             |
| `session-source.tar.gz`        | Saved source, user edits, untracked project documents, skills, and selected evidence. |
| `SESSION-HANDOFF.md`           | Original detailed session context and next steps.                                     |
| `session-checkpoint.json`      | Saved commit, owned files, and ticket ledger.                                         |
| `remaining-user-changes.patch` | Backup of tracked user changes excluded from the WIP.                                 |
| `checkpoint-working-tree.txt`  | Expected remaining working-tree state at the original pause.                          |
| `units.tsv`                    | Numbered ticket progress without a false acceptance claim.                            |
| `xstack-source.tar.gz`         | Workflow-tool source for installation on the next machine.                            |
| `host-tool-versions.txt`       | Actual tool versions recorded while packaging.                                        |
| `verification.json`            | Results of the local restore smoke check.                                             |
| `SHA256SUMS`                   | Transfer-integrity hashes for the packaged files.                                     |

Checksums detect accidental corruption. Transfer the folder through a channel you trust. Do not treat unsigned checksums as proof of the sender's identity.
